<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>formulaire contact</title>
</head>
<body>
<?php

$errorAlert = '';
$errorAlertName = '';
$red_border_name = '';

$display_success = 'none';
$display_fail = 'none';

if (isset($_POST["submit"])) {
    $name = $_POST['name'];
    $messageFrom = $_POST['email'];
    $message = $_POST['message'];

    $mailTo = "z1goku@hotmail.com";
    $headers = "From: ".$messageFrom;
    $txt = "You have received an email from ".$name.".\n\n".$message;   
   

    // Check name
    if (empty($name)) {
        $errorAlert .= 'error';
        $errorAlertName .= 'Veuillez saisir votre nom.';
        $red_border_name = '1px solid tomato';
    } 
    
    // Check email 
    if (empty($messageFrom) && filter_var  ($messageFrom, FILTER_VALIDATE_EMAIL) === false) {
        $errorAlert .= 'error';
        $errorAlertMail .= 'Veuillez saisir une adresse valide.';
        $red_border_mail = '1px solid tomato';
    }
    
    //Check message
    if (!$message) {
        $errorAlert .= 'error';
        $errorAlertMessage .= 'Veuillez saisir un message.';
        $red_border_message = '1px solid tomato';
    } 

    if (!$errorAlert) {
        mail($mailTo, $txt, $headers);
        $final_alert = '<div class="final_alert">Merci pour votre message! Je vous réponds dans les 24 heures.</div>';
        $display_success = 'flex';
		$display_fail = 'none';
        } else {
        $final_alert = '<div class="final_alert">Une erreur est survenue lors de l\'envoi de votre message.<br>Veuillez réessayer.</div>';
        $display_success = 'none';
        $display_fail = 'flex';
    } 

} #fermeture de if (isset($_POST["submit"]))

?>
	
	<div class="final_alert" style="display:<?php echo $display_success;?>">
		Merci pour votre message! Je vous réponds dans les 24 heures.
	</div>
	<div class="final_alert" style="display:<?php echo $display_fail;?>">
		Une erreur est survenue lors de l'envoi de votre message.<br>Veuillez réessayer.
	</div>

	<div class="form_content">
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" 
			method="post"
			class="contact_form" id="contact_form">
        
            <!-- nom -->
            <div class="input_div">
                <input id="name" class="input" type="text" name="name"
                    style="border-bottom:<?php echo $red_border_name;?>;">
                <label class="row" for="name">Nom</label>
            </div>
            <div class="input_alert"
                style="color: tomato; max-height: 3vh; text-align: start; margin-bottom: 3vh;">
                <?php echo $errorAlertName;?>
            </div>

            <div class="input_div button_div">
                <button class="btn" type="submit" name="submit" id="submit_btn">ENVOYER</button>
            </div>
		</form>
	</div>
    
</body>
</html>